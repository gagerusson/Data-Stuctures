#include <iostream>
#include "arrayFunctions.h"

using namespace std;

void arrayFunctions:: printArray(const int array[], unsigned int size) {
    int count = 0;
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            cout << array[count] << "      ";
            count++;
        }
        cout << endl;
    }
}

bool arrayFunctions:: push_back(int array[], unsigned int maxSize, int value, unsigned int& nFilled) {
    if (nFilled < maxSize) {
        array[nFilled] = value;
        nFilled++;
        return true;
    }
    return false;
}

int arrayFunctions:: find(const int array[], unsigned int size, int value) {
    for (int i = 0; i < size; i++) {
        if (array[i] == value) {
            return i;
        }
    }
    return size;
}

bool arrayFunctions:: remove(int array[], unsigned int &size, unsigned int pos) {
    if (pos >= size) {
        return false;
    }
    for (int i = pos; i < size; i++) {
        array[i] = array[i+1];
    }
    size--;
    return true;
}

bool arrayFunctions:: insert(int array[], unsigned int maxSize, unsigned int & nFilled, unsigned int pos, int value) {
    if ((nFilled > maxSize) || (pos > nFilled)) {
        return false;
    }
    for (int i = nFilled; i > pos; i--) {
        array[i + 1] = array[i];
    }
    array[pos] = value;
    return true;
}